#ifndef _RESINIT_H
#define _RESINIT_H

extern IFparm RESpTable[ ];
extern IFparm RESmPTable[ ];
extern char *RESnames[ ];
extern int RESpTSize;
extern int RESmPTSize;
extern int RESnSize;
extern int RESiSize;
extern int RESmSize;

#endif
